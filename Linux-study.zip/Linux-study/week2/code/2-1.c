#include "ch2.h"
int main(){
   int ret;
   ret = write(1,"Hello world!\n",13);
   exit(0);
}
