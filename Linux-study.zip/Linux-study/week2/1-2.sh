# ./bash
echo "nnskd"
clear
