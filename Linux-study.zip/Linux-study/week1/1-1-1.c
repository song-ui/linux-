#include<stdio.h>
int main(){
  printf("week1-1\n");
  return 0;
}
