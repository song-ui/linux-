#include <stdio.h>
int main(){
   printf("week1\n");
   return 0;
}
